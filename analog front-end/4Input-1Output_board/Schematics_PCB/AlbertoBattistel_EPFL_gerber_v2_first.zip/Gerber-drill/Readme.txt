Contact:
Alberto Battistel

Email:
alberto.battistel@epfl.ch

Address:
EPFL Valais Wallis
Laboratoire d�Electrochimie Physique et Analytique (LEPA)
Rue de l'Industrie 17
Case Postale 440
CH-1951 Sion

updated version: 6 February 2017

features
board with 2 copper layer
dimensions: 182.86 mm * 83.82 mm
silkscreen only on top
soldermask on top and bottom

filenames

top silkscreen: schematic3-F.SilkS

top soldermask: schematic3-F.Mask

top copper: schematic3-F.Cu

bottom copper: schematic3-B.Cu

bottom soldermask: schematic3-B.Mask

board outline: schematic3-Edge.Cuts

NC Drill: schematic3.drl